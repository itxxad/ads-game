# Urban Life Game - Finalized Code

✅ Player health and combat system  
✅ NPC manager and GTA-style dialogues  
✅ Clubs, jobs, in-game currency (ADS)  
✅ Admin control renamed to "AD"  
✅ Day/night & weather cycle  
✅ Inventory and groups  
✅ Map style: GTA SA 60%, Las Vegas 25%, Brookhaven 10%, Hollywood 5%

Organized in `/Assets/Scripts/` folder.

**Edit, upload to GitHub, or open in Unity (desktop needed to run).**
using UnityEngine;

public class CombatSystem : MonoBehaviour
{
    public void Attack(PlayerStats attacker, PlayerStats target, string weapon, string hitLocation)
    {
        int damage = 0;
        if (weapon == "gun")
        {
            if (hitLocation == "neck") damage = 15;
            else if (hitLocation == "torso" || hitLocation == "head") damage = 5;
        }
        else if (weapon == "knife")
        {
            if (hitLocation == "neck" || hitLocation == "head") damage = attacker.health;
            else damage = 10;
        }
        else if (weapon == "fist")
        {
            damage = 1;
        }
        target.ApplyDamage(damage);
    }
}
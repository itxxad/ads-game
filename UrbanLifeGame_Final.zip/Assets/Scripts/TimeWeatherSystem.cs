using UnityEngine;

public class TimeWeatherSystem : MonoBehaviour
{
    public float gameTime = 0;
    public string weather = "Clear";

    void Update()
    {
        gameTime += Time.deltaTime;
    }
}
using UnityEngine;
using System.Collections.Generic;

public class ClubManager : MonoBehaviour
{
    public Dictionary<string, List<PlayerStats>> clubs = new Dictionary<string, List<PlayerStats>>();

    void Start()
    {
        string[] sports = { "FieldHockey", "Rugby", "Chess", "Cricket", "Tennis", "Basketball", "Soccer" };
        foreach (string sport in sports)
        {
            clubs[$"{sport}_Club1"] = new List<PlayerStats>();
            clubs[$"{sport}_Club2"] = new List<PlayerStats>();
        }
    }

    public void MonthlyCompetition(string clubName)
    {
        List<PlayerStats> members = clubs[clubName];
        float prizePerPlayer = 1000000f / members.Count;
        foreach (PlayerStats p in members)
        {
            p.ADS += prizePerPlayer;
            Debug.Log($"{p.playerName} won {prizePerPlayer} ADS!");
        }
    }
}
using UnityEngine;
using System.Collections.Generic;

public class InventorySystem : MonoBehaviour
{
    public List<string> inventory = new List<string>(12);
    public List<string> carTrunk = new List<string>(10);
    public List<string> fridge = new List<string>(10);
    public List<string> backpack = new List<string>(5);
    public List<string> pocket = new List<string>(2);
}
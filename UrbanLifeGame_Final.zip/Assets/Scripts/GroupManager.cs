using UnityEngine;
using System.Collections.Generic;

public class Group
{
    public string name;
    public List<PlayerStats> members = new List<PlayerStats>();
    public float sharedMoney = 0;

    public void ShareItem(string item, PlayerStats giver, PlayerStats receiver)
    {
        Debug.Log($"{giver.playerName} shared {item} with {receiver.playerName}");
    }
}
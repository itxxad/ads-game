using UnityEngine;

public class PlayerStats : MonoBehaviour
{
    public int health = 100;
    public float ADS = 0;  // in-game currency
    public bool isAD = false;
    public string playerName;
    public string fightingStyle = "None";

    void Update()
    {
        if (System.DateTime.Now.DayOfWeek == System.DayOfWeek.Sunday)
        {
            Debug.Log($"{playerName} is at church.");
        }
    }

    public void ApplyDamage(int amount)
    {
        health -= amount;
        if (health <= 0) Die();
    }

    void Die()
    {
        Debug.Log($"{playerName} has died. Waiting for AD permission to respawn.");
    }
}
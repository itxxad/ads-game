using UnityEngine;
using System.Collections.Generic;

public class AdminControl : MonoBehaviour
{
    public List<PlayerStats> allPlayers;
    private string secretCode = "AD1234";

    public void GiveADPower(PlayerStats player, string code)
    {
        if (code == secretCode)
        {
            player.isAD = true;
            Debug.Log($"{player.playerName} now has admin power!");
        }
    }

    public void KickPlayer(PlayerStats player)
    {
        Debug.Log($"{player.playerName} was kicked by AD.");
    }

    public void TakeItem(PlayerStats player, string item)
    {
        Debug.Log($"AD took {item} from {player.playerName}");
    }

    public void RespawnPlayer(PlayerStats player)
    {
        player.health = 100;
        Debug.Log($"{player.playerName} respawned by AD.");
    }
}
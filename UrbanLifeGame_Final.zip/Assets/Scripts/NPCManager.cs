using UnityEngine;

public class NPCManager : MonoBehaviour
{
    public NPC[] npcs;

    void Start()
    {
        npcs = new NPC[99];
        for (int i = 0; i < 99; i++)
        {
            npcs[i] = new NPC($"NPC_{i}");
        }
    }
}

public class NPC
{
    public string npcName;
    public string[] dialogues = {
        "Hey, watch where you’re going!",
        "Get outta my way!",
        "Freeze! Police!",
        "Put your hands up!",
        "Welcome to Ammu-Nation!"
    };

    public NPC(string name)
    {
        npcName = name;
    }

    public void Speak()
    {
        string randomLine = dialogues[Random.Range(0, dialogues.Length)];
        Debug.Log($"{npcName} says: {randomLine}");
    }
}
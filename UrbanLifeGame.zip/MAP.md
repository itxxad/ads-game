# Urban Life Game Map Design

This document describes the planned map layout and zones for the game, combining styles from GTA San Andreas, Las Vegas, Brookhaven, and Hollywood.

## 🌆 Zones & districts

| Zone | Style & vibe | Key buildings |
|--|--|--|
| **Downtown / Neon City** (25%) | Las Vegas feel: neon lights, casinos, hotels, malls | Casino, 2 nightclubs, big hotel, luxury apartments, radio station |
| **Suburbs / Residential** (10%) | Brookhaven vibe: calm houses & roads | Player-built houses, small shops, local restaurants, church |
| **Industrial & docks** (10%) | GTA San Andreas-style warehouses, ship docks | Car dealership, car service, warehouses, scrapyard |
| **City center & business** (20%) | GTA vibe: mid-rise buildings, offices | Police station, gun store (Ammu-Nation style), banks, doctor, pharmacy, supermarket |
| **Entertainment zone** (10%) | Sports & fun: mini-games & fields | Football field, rugby, hockey, basketball court, tennis, cricket ground, chess park |
| **Hollywood hill** (5%) | Landmark zone | Big sign on hill, fancy houses, viewpoints |

## 🚗 Road network
- Circular highway around whole city
- Main roads lead to each major district
- Winding road to Hollywood hill

## 🏠 Player houses
- Players can buy/build houses in suburbs
- Luxury houses on Hollywood hill

## 🛍 Shops & places
- Gun store (GTA San Andreas style)
- Pharmacy & doctor
- Supermarket
- Car dealership (with African car models)
- Mall with clothing shops & restaurants
- Drug dealer hidden spot
- Police station
- Public pool
- Many restaurants
- Mini-games areas
- Church

## 🌦 Environment
- Day/night cycle (2 real hours = 24h in-game)
- Weather:
  - Rain every 19 days
  - Cloudy day weekly
  - Snow ~3× every 3 months
  - Fog once every 5 months

## 🧍 NPC placement
- Total: 99 NPCs
- Some static (shopkeepers, guards)
- Some moving around town and in vehicles
- <5% chance NPC may stalk/kill player

## 🗣 Sound & voice
- Radio station plays music from admin's Apple Music playlist
- NPCs say famous GTA lines (voice or TTS)
- Las Vegas & Brookhaven style background ambience

## 💰 Gameplay features on the map
- Job places (science, factory, restaurants, maid, sports clubs, self-employment office)
- Car dealership & custom shop
- Group houses (max 5 players)
- Hidden drug dealer spots
- Banks for money storage/donations

## ✅ Next step
This file can be committed to GitHub as `MAP.md` or included in README.md.
Optionally, add a drawn map image to the repository under `/Assets/Map/`.

# Urban Life Game

This is the project structure for the **Urban Life Game** idea. It includes the game concept, map design, and instructions for publishing as a free website using GitHub Pages.

## 📦 Project structure

UrbanLifeGame/
├── index.html        # Placeholder home page (you can edit to add real game code)
├── README.md         # Project overview & setup instructions
└── MAP.md            # Detailed game map & design notes

## 🌍 How to publish on GitHub Pages (from iPad or browser)

1. Go to your repo on GitHub → tap ⚙ **Settings**
2. Scroll to **Pages**
3. Under **Source**, select:
   - Branch: `main`
   - Folder: `/ (root)`
4. Tap **Save**
5. Wait 30–60 seconds → your site is live at:

https://yourusername.github.io/UrbanLifeGame

## 🗺 Map summary
- GTA San Andreas vibe ~60%
- Las Vegas downtown ~25%
- Brookhaven suburban ~10%
- Hollywood landmarks ~5%

For full details see `MAP.md`.

## ✏ Next steps
- Replace `index.html` with your real HTML/JavaScript game code
- Add assets, scripts, sounds and models
- Commit & push → your live site updates automatically!

**Created with help from ChatGPT.**
